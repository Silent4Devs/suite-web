<!DOCTYPE html>
<html>
<head>
	<title>Lista Maestra</title>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<style type="text/css">
		body{
			font-size: 10pt;
			font-family: arial;
		}
		table{
			border-collapse: collapse;
		}
		td{
			border: 1px solid #ccc;
			padding: 10px;
		}
		.encabezado td{
			text-align: center;
			padding: 30px 0;
		}
		div{
			width: 100%;
			margin-bottom: 20px;
		}
		table{
			width: 100%;
		}
		.td_primera{
			width: 25%;
		}
		th{
			background-color: #321fdb;
			border: #ccc solid 1px;
			padding: 10px;


		}
		.subtabla td{
			padding: 0;
			height: 20px;
		}
	</style>
</head>
<body>
	<div class="encabezado">
		<table width="100%">
			<tr style="font-weight: bold;">
				<td width="30%"><img src="i"></td>
				<td style="font-size:12pt;">Lista Maestra</td>
				<td width="30%">F-SGI-005 V1 <br>

                </td>
			</tr>
		</table>
	</div>



		<table  >
			<thead>
				<tr style="color:#ffffff; font-weight:normal;">
					<th>Codigo</th>
					<th>Nombre del Documento</th>
					<th>Fecha de Creación</th>
					<th>Versión Vigente</th>
          <th>Fecha de Ultima Versión</th>
          <th>Elaboró</th>
          <th>Aprobó</th>
				</tr>

			</thead>

			<tbody>
				<tr>

					<td></td>
					<td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
				</tr>
			</tbody>
		</table>





</body>
</html>
