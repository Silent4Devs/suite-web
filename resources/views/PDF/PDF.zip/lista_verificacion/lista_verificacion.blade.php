<!DOCTYPE html>
<html>
<head>
	<title>Lista de Verificación</title>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<style type="text/css">
		body{
			font-size: 10pt;
			font-family: arial;
		}
		table{
			border-collapse: collapse;
		}
		td{
			border: 1px solid #ccc;
			padding: 10px;
		}
		.encabezado td{
			text-align: center;
			padding: 30px 0;
		}
		div{
			width: 100%;
			margin-bottom: 20px;
		}
		table{
			width: 100%;
		}
		.td_primera{
			width: 25%;
		}
		th{
			background-color: #eee;
			border: #ccc solid 1px;
			padding: 10px;
		}
		.subtabla td{
			padding: 0;
			height: 20px;
		}
	</style>
</head>
<body>
	<div class="encabezado">
		<table width="100%">
			<tr>
				<td width="30%"><img src="i"></td>
				<td>Lista de Verificación</td>
				<td width="30%">F-SGI-023 V1 <br>
                    {{date('j F Y')}}
                </td>
			</tr>
		</table>
	</div>
	<div class="">
		<table>
			<tr>
				<td class="td_primera">Fecha</td>
				<td>
                    {{$datavalues->fecha_id}}
                </td>
			</tr>
		</table>
	</div>
	<div class="">
		<table>
			<tr>
				<td class="td_primera">NOMBRE DEL AUDITOR</td>
				<td>{{$datavalues->equipoauditor}}</td>
			</tr>
		</table>
	</div>
	<div class="">
		<table>
			<tr>
				<td class="td_primera">NOMBRE DEL AUDITADO</td>
				<td></td>
			</tr>
			<tr>
				<td class="td_primera">PUESTO</td>
				<td></td>
			</tr>
		</table>
	</div>
	<div class="">
		<table>
			<tr>
				<td class="td_primera">PROCESO AUDITADO</td>
				<td></td>
			</tr>
		</table>
	</div>
	<div class="">
		<table>
			<thead>
				<tr>
					<th>PUNTO DE REFERENCIA</th>
					<th>PREGUNTAS</th>
					<th style="padding: 0;">
						<table class="subtabla">
							<tr>
								<td style="border: none;">CUMPLE</td>
							</tr>
							<tr>
								<td>
									<table>
										<tr>
											<td bgcolor="#25e45c">SI</td>
											<td bgcolor="#e2e425">NO</td>
											<td bgcolor="#e49825">N/A</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</th>
					<th>OBSERVACIONES</th>
					<th>EVIDENCIAS PRESENTADAS</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<table class="subtabla">
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
					<td></td>
					<td></td>
				</tr>
			</tbody>
		</table>
	</div>
</body>
</html>
